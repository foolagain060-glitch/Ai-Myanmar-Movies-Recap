# AI Myanmar Movie Recap — starter project

This is a starter MVP with:
- Android app UI (Kotlin + Jetpack Compose)
- Video file upload to a Python/FastAPI backend
- Direct public MP4/WebM URL input
- Audio transcription with OpenAI
- Original Burmese recap generation (summary, not a verbatim script)

## Important limitations
- This starter does **not** yet process YouTube watch-page links. The URL mode currently accepts direct media-file URLs (for example, an authorized `.mp4` URL). YouTube needs a separate, compliant captions/provider integration.
- Use only videos you own, have permission to process, or are otherwise legally allowed to use. The recap prompt asks for original wording and avoids reproducing dialogue.
- This is source code, not an installed APK. Build it with Android Studio and run the backend on a secure server.
- Never put your OpenAI API key inside the Android app. Keep it on the backend.

## Backend setup
Requirements: Python 3.10+, FFmpeg installed and available as `ffmpeg`.

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

Set the API key in the backend environment:
```bash
# macOS/Linux
export OPENAI_API_KEY="YOUR_KEY"
# Windows PowerShell
$env:OPENAI_API_KEY="YOUR_KEY"
```

Start:
```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

For Android emulator testing, set `BASE_URL` in `MainActivity.kt` to `http://10.0.2.2:8000/`.
For a real phone, use your backend's HTTPS address. Do not expose an unauthenticated development server publicly.

## Android setup
1. Open the `android` folder in Android Studio (recent version).
2. Let Gradle sync.
3. Run on an Android device or emulator.
4. Update `BASE_URL` in `MainActivity.kt`:
   - Emulator: `http://10.0.2.2:8000/`
   - Real phone: your secure backend URL, ending with `/`.

The Android app currently uses Android's document picker to select a video. It sends the file or direct media URL to the backend.

## API
- `POST /recap/upload` — multipart field `file`
- `POST /recap/url` — JSON `{ "url": "https://.../movie.mp4" }`
- Response: `{ "recap": "...", "transcript": "..." }`

## Production work still needed
Authentication, upload quotas, storage cleanup, job queue/progress, abuse protection, privacy policy, billing (if needed), robust URL allowlisting/SSRF protection, and YouTube captions integration.
