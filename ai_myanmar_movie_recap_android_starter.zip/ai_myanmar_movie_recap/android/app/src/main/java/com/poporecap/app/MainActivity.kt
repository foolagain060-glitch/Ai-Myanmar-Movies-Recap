package com.poporecap.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

private const val BASE_URL = "http://10.0.2.2:8000/" // emulator; change for real device HTTPS server

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RecapScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecapScreen() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var link by remember { mutableStateOf("") }
    var recap by remember { mutableStateOf("") }
    var transcript by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("ဗီဒီယိုဖိုင်တင်ပါ သို့မဟုတ် direct video link ထည့်ပါ။") }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            videoUri = uri
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            status = "ဗီဒီယိုဖိုင် ရွေးချယ်ပြီးပါပြီ။"
        }
    }

    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = { Text("AI Myanmar Movie Recap") })
        }) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("နိုင်ငံခြားဗီဒီယိုကို မြန်မာ Movie Recap အဖြစ် ပြောင်းမယ်", style = MaterialTheme.typography.titleMedium)
                Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Video ဖိုင် Upload လုပ်မယ်")
                }
                Text(videoUri?.lastPathSegment ?: "ဖိုင်မရွေးရသေးပါ")
                OutlinedTextField(
                    value = link, onValueChange = { link = it },
                    label = { Text("Direct MP4 / MOV / WebM Link") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Text("မှတ်ချက် - လက်ရှိ version သည် YouTube watch-page link ကို မထောက်ပံ့သေးပါ။")
                Button(
                    enabled = !busy && (videoUri != null || link.isNotBlank()),
                    onClick = {
                        busy = true
                        status = "ဗီဒီယိုကို စစ်ဆေးပြီး Recap ပြုလုပ်နေပါသည်..."
                        thread {
                            try {
                                val result = if (videoUri != null) uploadVideo(context, videoUri!!)
                                             else sendUrl(link.trim())
                                recap = result.optString("recap")
                                transcript = result.optString("transcript")
                                status = "Recap ပြီးပါပြီ။"
                            } catch (e: Exception) {
                                status = "မအောင်မြင်ပါ: ${e.message ?: "ပြန်စမ်းကြည့်ပါ"}"
                            } finally { busy = false }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (busy) "လုပ်ဆောင်နေသည်..." else "မြန်မာ Recap ထုတ်မယ်") }

                Text(status, color = MaterialTheme.colorScheme.primary)
                if (recap.isNotBlank()) {
                    Text("အသေးစိတ် မြန်မာ Movie Recap", style = MaterialTheme.typography.titleLarge)
                    SelectionContainerCompat(recap)
                    OutlinedButton(onClick = {
                        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Myanmar Recap", recap))
                        status = "Recap ကို Copy လုပ်ပြီးပါပြီ။"
                    }, modifier = Modifier.fillMaxWidth()) { Text("Recap Copy လုပ်မယ်") }
                    TextButton(onClick = { transcript = if (transcript.isBlank()) "Transcript မရှိပါ" else transcript }) {
                        Text("Transcript ကို ကြည့်ရန်")
                    }
                    if (transcript.isNotBlank()) Text(transcript)
                }
            }
        }
    }
}

@Composable
private fun SelectionContainerCompat(value: String) {
    androidx.compose.foundation.text.selection.SelectionContainer {
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}

private fun sendUrl(link: String): JSONObject {
    val conn = (URL(BASE_URL + "recap/url").openConnection() as HttpURLConnection)
    conn.requestMethod = "POST"
    conn.connectTimeout = 15000
    conn.readTimeout = 1800000
    conn.doOutput = true
    conn.setRequestProperty("Content-Type", "application/json")
    conn.outputStream.use { it.write(JSONObject().put("url", link).toString().toByteArray()) }
    return readResult(conn)
}

private fun uploadVideo(context: android.content.Context, uri: Uri): JSONObject {
    val boundary = "----RecapBoundary${System.currentTimeMillis()}"
    val conn = (URL(BASE_URL + "recap/upload").openConnection() as HttpURLConnection)
    conn.requestMethod = "POST"
    conn.connectTimeout = 15000
    conn.readTimeout = 1800000
    conn.doOutput = true
    conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
    DataOutputStream(conn.outputStream).use { out ->
        val name = "video.mp4"
        out.writeBytes("--$boundary\r\n")
        out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"$name\"\r\n")
        out.writeBytes("Content-Type: application/octet-stream\r\n\r\n")
        context.contentResolver.openInputStream(uri)!!.use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                out.write(buffer, 0, n)
            }
        }
        out.writeBytes("\r\n--$boundary--\r\n")
    }
    return readResult(conn)
}

private fun readResult(conn: HttpURLConnection): JSONObject {
    val code = conn.responseCode
    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
    val body = stream.bufferedReader().use(BufferedReader::readText)
    if (code !in 200..299) throw IllegalStateException(body)
    return JSONObject(body)
}
