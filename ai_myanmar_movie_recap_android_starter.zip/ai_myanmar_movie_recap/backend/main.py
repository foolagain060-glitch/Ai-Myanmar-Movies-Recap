import os
import tempfile
import subprocess
from pathlib import Path
from urllib.parse import urlparse

import requests
from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel, HttpUrl
from openai import OpenAI

app = FastAPI(title="AI Myanmar Movie Recap API")
MAX_BYTES = 500 * 1024 * 1024  # 500 MB MVP limit
client = OpenAI()  # reads OPENAI_API_KEY from backend environment

class UrlRequest(BaseModel):
    url: HttpUrl

def transcribe_and_recap(video_path: str) -> dict:
    work = Path(tempfile.mkdtemp(prefix="recap_"))
    audio_path = work / "audio.mp3"
    try:
        # Extract audio for transcription. FFmpeg must be installed.
        p = subprocess.run(
            ["ffmpeg", "-y", "-i", video_path, "-vn", "-ac", "1",
             "-ar", "16000", "-b:a", "64k", str(audio_path)],
            capture_output=True, text=True, timeout=1800
        )
        if p.returncode != 0 or not audio_path.exists():
            raise HTTPException(422, "ဒီဗီဒီယိုထဲက အသံကို ဖတ်မရပါ။ ဖိုင်ကို စစ်ဆေးပေးပါ။")

        with audio_path.open("rb") as audio:
            transcript_result = client.audio.transcriptions.create(
                model="gpt-4o-mini-transcribe",
                file=audio
            )
        transcript = getattr(transcript_result, "text", "") or str(transcript_result)
        if not transcript.strip():
            raise HTTPException(422, "အသံထဲမှ စကားပြောစာသား မရရှိပါ။")

        response = client.responses.create(
            model="gpt-4.1-mini",
            instructions=(
                "You are a Burmese-language movie recap writer. Write an original, "
                "detailed Burmese-language recap based only on the supplied transcript. "
                "Explain the plot chronologically in natural, engaging Burmese. "
                "Identify characters only when the transcript supports it. Separate "
                "major story sections with headings. Do not invent scenes, motives, "
                "names, or endings. If information is unclear, say so briefly. "
                "Do not reproduce dialogue verbatim or imitate a copyrighted script; "
                "summarize in fresh wording. Avoid claiming visual details that are "
                "not present in the transcript."
            ),
            input=(
                "အောက်ပါ transcript ကို အခြေခံပြီး မြန်မာဘာသာဖြင့် အသေးစိတ် "
                "Movie Recap ရေးပေးပါ။ ဇာတ်လမ်းအစမှ အဆုံးအထိ အစဉ်လိုက်ရေးပါ။\n\n"
                + transcript[:100000]
            )
        )
        recap = response.output_text
        return {"recap": recap, "transcript": transcript}
    finally:
        try:
            for item in work.iterdir():
                item.unlink(missing_ok=True)
            work.rmdir()
        except Exception:
            pass

@app.get("/health")
def health():
    return {"ok": True, "service": "AI Myanmar Movie Recap"}

@app.post("/recap/upload")
async def recap_upload(file: UploadFile = File(...)):
    suffix = Path(file.filename or "video.mp4").suffix or ".mp4"
    temp_path = None
    total = 0
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            temp_path = tmp.name
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_BYTES:
                    raise HTTPException(413, "ဖိုင်အရွယ်အစား 500 MB ထက် မကျော်ရပါ။")
                tmp.write(chunk)
        return transcribe_and_recap(temp_path)
    finally:
        await file.close()
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)

@app.post("/recap/url")
def recap_url(request: UrlRequest):
    # MVP intentionally accepts direct media URLs only, not video-platform watch pages.
    url = str(request.url)
    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise HTTPException(400, "လုံခြုံရေးအတွက် HTTPS link သာ လက်ခံပါသည်။")
    if not parsed.path.lower().endswith((".mp4", ".mov", ".m4v", ".webm", ".mkv")):
        raise HTTPException(400, "လက်ရှိ version တွင် direct MP4/MOV/WebM video link သာ အသုံးပြုနိုင်ပါသည်။ YouTube link မပါဝင်သေးပါ။")
    temp_path = None
    try:
        with requests.get(url, stream=True, timeout=(10, 60)) as r:
            r.raise_for_status()
            length = int(r.headers.get("content-length", "0"))
            if length and length > MAX_BYTES:
                raise HTTPException(413, "ဗီဒီယိုဖိုင်သည် 500 MB ထက် ကြီးနေပါသည်။")
            suffix = Path(parsed.path).suffix or ".mp4"
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                temp_path = tmp.name
                total = 0
                for chunk in r.iter_content(1024 * 1024):
                    if chunk:
                        total += len(chunk)
                        if total > MAX_BYTES:
                            raise HTTPException(413, "ဗီဒီယိုဖိုင်သည် 500 MB ထက် ကြီးနေပါသည်။")
                        tmp.write(chunk)
        return transcribe_and_recap(temp_path)
    except requests.RequestException:
        raise HTTPException(400, "Video link ကို ရယူမရပါ။ Link မှန်ကန်မှုနှင့် ခွင့်ပြုချက်ကို စစ်ဆေးပါ။")
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)
